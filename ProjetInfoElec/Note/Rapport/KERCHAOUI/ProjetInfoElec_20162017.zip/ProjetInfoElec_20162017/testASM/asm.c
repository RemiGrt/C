#include "asm.h"

/*! \file Assembleur.c
 *
 programme permet d'assembler un fichier assembleur safe.asm en bytecode dans un fichier safe.bin
 *
 * Utilisation en console: ./asm.o
 *
 * Compilation :    
 * gcc asm.c -o asm.o

*/

int currentLabel; 
int currentInst; //variable pour l'indice du tableau opcode, instruction en cours de traitement
int currentRef; 
int instructionDico;
char line[MAX_LINE_SIZE]; //tableau qui contient la ligne du fichier .asm étudiée
unsigned int codeSegment[MAX_CODESEGMENT_SIZE]; //tableau de l'opcode décodé




void addInstructionName(char *name, int opcod, int type, char *format, int nbops)
{
    tabInstructionNames[instructionDico].name = name; 
    tabInstructionNames[instructionDico].opcod = opcod; 
    tabInstructionNames[instructionDico].type = type;
    tabInstructionNames[instructionDico].format = format;
    tabInstructionNames[instructionDico].nbops = nbops; //nombre d'opérande
    instructionDico++; //on attend l'instruction suivante à remplir dans le dico
}


void addCode(char *line, int opcod, char *format, int type)
{
    printf("\n On est dans addCode Congrats\n");
    printf("type : -%d-\n",type);
    printf("opcod : -%d-\n",opcod);
    printf("line : -%s-\n\n",line);

    int i=0,j=0;
    int argument=0;
    int detectionEtiquette=0;
    char etiquetteTrouvee[MAX_LINE_SIZE];

    if(type == 0) //pas d'opérande
    {
	codeSegment[currentInst]=opcod;
	currentInst++; //on attend l'instruction suivante
    }
    else if(type == 1) //1 opérande
    {
	codeSegment[currentInst]=opcod;
	currentInst++;

	while(line[i]!='\n') // chercher jusqu'à la fin de la ligne
	{
	    printf("Le caractere est : -%c-\n", line[i]);
	   // printf("l'argument : -%d-\n",argument);
		
	    argument *= 10; //on multiplie par 10 
		
	    if((line[i]>='0') && (line[i]<='9')) //si le caractère est bien un nombre
	    {
			if(line[i-1]=='-') //si le nombre est négatif
			{
				argument -= line[i]-48; // car ASCII commence à 0 = 48
			}
			else
			{
				argument += line[i]-48;
			}
	    }
	i++;
	}
	printf("L'argument finale est: -%d-\n",argument);
	codeSegment[currentInst] = argument;
	printf("L'argument stocké est : -%u-\n",codeSegment[currentInst]);
	currentInst++; //wait next instruction	
    }
    else if(type == 3)//une opérande
    {
	codeSegment[currentInst]=opcod; //dans le tab d'instruction décrypté
	currentInst++;
	codeSegment[currentInst]=-1;

	while(line[i]!='\n') //si pas fini la ligne
	{
	    printf("Le caractere est -%c-\n",line[i]);
	    if(line[i]==0x09)	//tabulation
	    {
			detectionEtiquette++; // 2tabu
			printf("detectionEtiquette : -%d-\n", detectionEtiquette);
			i++;
	    }
	    else if(detectionEtiquette==2) //deb arg
	    {
			etiquetteTrouvee[j] = line[i]; //mémorissation pour reconstruire l'argument
			printf("Le caractere stocke est : -%c-\n",etiquetteTrouvee[j]);		
			j++;
			etiquetteTrouvee[j] = '\0';
			i++;
	    }
	    else
	    {
			i++;
	    }
	}

	for(i=0;i<MAX_LINE_SIZE;i++)
	{
	    tabReferences[currentRef].label[i]=etiquetteTrouvee[i]; // dans le tabref on met l'argument
	}
	printf("l'etiquette trouvee : -%s-\n",etiquetteTrouvee);
	printf("l'etiquette stockee : -%s-\n",tabReferences[currentRef].label);
	tabReferences[currentRef].addrInCode=currentInst; // indice du tablopcode
	currentRef++; //wait next ref
	currentInst++; //wait next instruction
    }
    else
    {
		printf("erreur d'ajout dans codeSegment\n");
    }
}

void decodeInstruction(char *line)
{
    int typeInstructionDecodee=-1, opcodDecodee=-1;
    int instructionDecodee=0;
    int i=0;	
    char *format;

    //identification de l'instruction 0 1 ou 3
    for(i=0; i<MAX_IDENTS_SIZE; i++)
    {
		if(strstr(line,tabInstructionNames[i].name)) //comparaison de la ligne avec dico pour savoir l'instruction
		{	
			//On retranscrit les spécification de l'instruction pour aider addcode
			printf("instruction du dictionnaire : %s\n",tabInstructionNames[i].name);
			typeInstructionDecodee = tabInstructionNames[i].type;
			opcodDecodee = tabInstructionNames[i].opcod;
			format = tabInstructionNames[i].format;
			instructionDecodee=1;
			i = MAX_IDENTS_SIZE; //décryptage de l'instruction effectué donc on sort de la boucle
		}
    }

    // Si instruction appeler addCode pour remplir codeSegment
    if(instructionDecodee=1)
    {	
		printf("l'instruction decryptee : %d\n",opcodDecodee);
		addCode(line, opcodDecodee, format, typeInstructionDecodee);
    }
    else
    {
		printf("FAIL de decryptage\n");
    }   
}

void resolveReferences(void)
{
    int i,j;

    for(i=0;i<currentRef;i++) //tab de ref
    {
		for(j=0;j<currentRef;j++) //tab de label
		{
			if(!strcmp(tabReferences[i].label,tab_labels[j].label)) //when ref find dans tab lab
			{
				codeSegment[tabReferences[i].addrInCode]=tab_labels[j].addr; // @ in tab opcode
				j=currentRef;//quit pour go to next ref
			}
		}
    }
}

void addLabel(char labelname[MAX_LINE_SIZE],int addr)
{
    int i=0;

    while(labelname[i]!='\n') //Toute la ligne jusqu'à la fin
    {
        if(labelname[i]==':')
        {
            labelname[i]='\0'; //fin du nom de l'étiquette
        }
	i++;
    }

    printf("labelname : -%s-\n",labelname);

    for(i=0;i<MAX_LINE_SIZE;i++) //encore Pour la ligne sans ":"
    {
        tab_labels[currentLabel].label[i] = labelname[i]; //recopie dans le nom de l'étiquette
    }

    printf("le labelname dans tab_label : -%s-\n",tab_labels[currentLabel].label);
    tab_labels[currentLabel].addr = addr; //@ where etiquette were found
    printf("adresse dans tab_label : -%d-\n",tab_labels[currentLabel].addr);
    currentLabel++; //wait next etiquette
}

void parseAsm(FILE *fin)
{
    malloc(sizeof(line));

    while(!strstr(line,"halt")) //Jusqu'à la fin si on lit HALT
    {	
		fgets(line, 100, fin); //ligne du fichier
	
		printf("-%s-\n",line);
        
        if(strstr(line,"#"))
        {
            printf("# C'est un commentaire c'est cool \n");
			//il s'agit d'un commentaire, on ne fait rien
        }
        else if(strstr(line,":"))
        {
            printf(": C'est un label c'est cool\n");
			addLabel(line,currentInst); // c'est une étiquette donc on appel addLabel
        }
        else //sinon c'est une instruction
        {
			printf(" C'est une instruction c'est cool \n");
            decodeInstruction(line); //on appel decodeInstruction pour la décrypter
        }
    }
	printf("C'est fini great by Sam and Sof\n");
	fgets(line, 20, fin);
	printf("-%s-\n",line);
}

void generateBinary(FILE *fout)
{
    int i;
	
	fprintf(fout,"%d\n",currentInst); //Dans la 1rst line du file on écrit le nombre d'instruction
	
    for(i=0;i<currentInst;i++) //on look le fichier opcode décrypté
    {
		fprintf(fout,"%d : %d\n",i,codeSegment[i]); //recopie dans le fichier.bin
    }
}

int main()
{
	FILE *fichierasm=fopen("safe.asm","r"); //open du fichier assembleur
	FILE *fichierbin=fopen("safe.bin","w"); //open du fichier bytecode
	
	if(fichierasm!=NULL) //si .asm not empty
	{
		currentLabel = 0;
		currentRef = 0;	
		currentInst = 0;
		instructionDico = 0;
		int i =0;
	
	//construction du dictionnaire voir aussi vm_codops.h
//instruction
	//si type 0 : pas de décryptage d'opérandes utilse
		addInstructionName("add", I_ADD, 0, "", 0);
		addInstructionName("sub", I_SUB, 0, "", 0);
		addInstructionName("mult", I_MULT, 0, "", 0);
		addInstructionName("div", I_DIV, 0, "", 0);
		addInstructionName("neg", I_NEG, 0, "", 0);
		addInstructionName("and", I_AND, 0, "", 0);
		addInstructionName("or", I_OR, 0, "", 0);
		addInstructionName("not", I_NOT, 0, "", 0);
		addInstructionName("eq", I_EQ, 0, "", 0);
		addInstructionName("ls", I_LS, 0, "", 0);
		addInstructionName("gt", I_GT, 0, "", 0);
		addInstructionName("halt", I_HALT, 0, "", 0);
	//si type 1 : besoin d'un décryptage d'une opérande
		addInstructionName("pushi", I_PUSHI, 1, "	%s	%d", 1);
		addInstructionName("push", I_PUSH, 1, "%s	%d", 1);
		addInstructionName("pop", I_POP, 1, "%s	%d", 1);
	//si type 3 : besoin d'un décryptage d'une étiquette
		addInstructionName("jf", I_JF, 3, "%s	%s", 1); 
		addInstructionName("j", I_J, 3, "%s	%s", 1);

		parseAsm(fichierasm); //analyse .asm
		resolveReferences();
		generateBinary(fichierbin); 

		printf("\nbytecod final by Sam & Sof\n");
		printf("--------------------------------------\n");
		for(i=0;i<currentInst;i++)
		{
		    printf("%d : %d\n",i,codeSegment[i]);
		}
		printf("---------------by Sam & Sof--------------\n");
	}
}

// faire test seul aussi si on veut

