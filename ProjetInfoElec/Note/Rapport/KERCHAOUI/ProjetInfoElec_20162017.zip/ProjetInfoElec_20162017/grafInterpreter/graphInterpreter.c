#include <stdio.h>
#include <stdlib.h>


int But0, But1, Pot, riseBut0, riseBut1, stable=0;	//boutons et stabilité
int Old_But0, Old_But1; // anciennes valeurs des boutons
int Appel_X0=0, Appel_X1=0, Appel_X2=0, Appel_X3=0; //Appels
int Reponse_X0=0, Reponse_X1=0, Reponse_X2=0, Reponse_X3=0; //Réponses	
int Old_X0=0, Old_X1=0, Old_X2=0, Old_X3=0; //Anciennes valeurs d'étapes
int X0=0, X1=0, X2=0, X3=0; // étapes

int main()
{
	X0=1;
	while(1)

	{
		Old_But0=But0;
		Old_But1=But1;

		printf("Entrer valeur But0 : ");
		scanf("%d",&But0);
		printf("Entrer valeur But1 : ");
		scanf("%d", &But1);
		printf("Entrer valeur Pot : ");
		scanf("%d", &Pot);

		if(Old_But0==0 && But0==1) // calcul de front sur but0
		{
			riseBut0=1;
		}
		else riseBut0=0;

		if(Old_But1==0 && But1==1) // calcul de front sur but1
		{
			riseBut1=1;
		}
		else riseBut1=0;

		stable=0;

		while(stable==0) // test stabilité
		{
			Old_X0=X0;
			Old_X1=X1;
			Old_X2=X2;
			Old_X3=X3;

			Appel_X0=0;
			Reponse_X0=0;
			Appel_X1=0;
			Reponse_X1=0;
			Appel_X2=0;
			Reponse_X2=0;
			Appel_X3=0;
			Reponse_X3=0;

			if(X0==1 && riseBut0==1 && Pot>128) //etape0
			{
				Appel_X1=1;
				Reponse_X0=1;
			}

			if(X1==1 && riseBut0==1 && Pot<128 ) //etape1
			{
				Appel_X2=1;
				Reponse_X1=1;
			}

			if(X2==1 && riseBut0==1 && Pot>128) //etape2
			{
				Appel_X3=1;
				Reponse_X2=1;
			}

			if(X3==1 && riseBut1 ==1)  //etape3
			{
				Appel_X0=1;
				Reponse_X3=1;
			}

			X0= (Appel_X0 || (X0 && !Reponse_X0));	
			X1= (Appel_X1 || (X1 && !Reponse_X1));	
			X2= (Appel_X2 || (X2 && !Reponse_X2));	
			X3= (Appel_X3 || (X3 && !Reponse_X3));	

			if(X0==Old_X0 && X1==Old_X1 && X2==Old_X2 && X3==Old_X3) //calcul stabilité
			{
				stable=1;
			}

			printf("\te0\te1\te2\te3\n");
			printf("oldX\t%d\t%d\t%d\t%d\n", Old_X0, Old_X1, Old_X2, Old_X3);
			printf("curX\t%d\t%d\t%d\t%d\n", X0, X1, X2, X3);
			printf("Appel\t%d\t%d\t%d\t%d\n", Appel_X0, Appel_X1, Appel_X2, Appel_X3);
			printf("Réponse\t%d\t%d\t%d\t%d\n\n", Reponse_X0, Reponse_X1, Reponse_X2, Reponse_X3);

		}
	}
}
